package com.cg.exception;

public class MenuNotFoundException extends Exception{
	public MenuNotFoundException() {
		super();
	}

	public MenuNotFoundException(String msg) {
		super(msg);
	}
}
