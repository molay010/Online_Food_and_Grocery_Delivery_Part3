package com.cg.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.dto.MenuDTO;
import com.cg.exception.MenuNotFoundException;

@FeignClient(name="Menu-service",url = "http://localhost:8048" )
public interface MenuService {
	
	@GetMapping("/menu/getById/{menuId}")
	public MenuDTO getMenuById(@PathVariable(value = "menuId") int menuId) throws MenuNotFoundException ;

}
