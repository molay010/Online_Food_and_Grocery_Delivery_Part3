package com.cg.service;

import com.cg.dto.CartDTO;
import com.cg.exception.AddToCartNotFoundException;
import com.cg.exception.CustomerNotFoundException;
import com.cg.exception.MenuNotFoundException;

public interface CartService {
	
	public CartDTO addToCart(CartDTO cartDTO) throws CustomerNotFoundException, MenuNotFoundException;
	 
	public String deleteMenu(int customerId, int menuId) throws AddToCartNotFoundException,MenuNotFoundException;
	
	public CartDTO getCartByCustomerId(int customerId);
	
	public String deleteCart(int cartId);
}
