package com.cg.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.client.CustomerService; // Importing CustomerService for customer-related operations
import com.cg.client.MenuService;
import com.cg.dto.CartDTO; // Importing CartDTO for data transfer between service and controller
import com.cg.dto.CustomerDTO; // Importing CustomerDTO for customer details
import com.cg.dto.MenuDTO;
import com.cg.entity.Cart; // Importing Cart entity class
import com.cg.exception.AddToCartNotFoundException; // Importing AddToCartNotFoundException for handling exceptions
import com.cg.exception.CustomerNotFoundException; // Importing CustomerNotFoundException for handling exceptions
import com.cg.exception.MenuNotFoundException;
import com.cg.repository.CartRepository; // Importing CartRepository for database operations
import com.cg.service.CartService; // Importing CartService interface

@Service // Indicates that this class is a service component in Spring framework
public class CartServiceImpl implements CartService {

    @Autowired // Autowires CartRepository for dependency injection
    private CartRepository cartRepository;

    @Autowired // Autowires CustomerService for dependency injection
    private CustomerService customerService;

    @Autowired // Autowires ProductService for dependency injection
    private MenuService menuService;

    // Method to add a product to the cart
	    @Override
	    public CartDTO addToCart(CartDTO cartDTO) throws CustomerNotFoundException, MenuNotFoundException {
	        int customerId = cartDTO.getCustomerId();
	        List<Integer> menuIds = cartDTO.getMenuId();
	
	        CustomerDTO customer = customerService.getCustomerById(customerId);
	        if (customer == null) {
	            throw new CustomerNotFoundException("Invalid customer ID");
	        }
	
	        Cart cart = cartRepository.findByCustomerId(customerId);
	        if (cart == null) {
	            cart = new Cart();
	            cart.setCustomerId(customerId);
	        }
	
	        for (Integer menuId : menuIds) {
	            MenuDTO menu = menuService.getMenuById(menuId);
	            if (menu == null) {
	                throw new MenuNotFoundException("Invalid Menu ID: " + menuId);
	            }
	
	            cart.getMenuId().add(menuId);
	            cart.setTotalItemsQuantity(cart.getTotalItemsQuantity() + 1);
	            cart.setTotalItemPrice(cart.getTotalItemPrice() + menu.getMenuPrice());
	        }
	
	        cartRepository.save(cart);
	
	        CartDTO responseDTO = new CartDTO();
	        responseDTO.setCartId(cart.getCartId());
	        responseDTO.setCustomerId(cart.getCustomerId());
	        responseDTO.setMenuId(cart.getMenuId());
	        responseDTO.setTotalItemPrice(cart.getTotalItemPrice());
	        responseDTO.setTotalItemsQuantity(cart.getTotalItemsQuantity());
	
	        return responseDTO;
	    
	    }
    // Method to delete a product from the cart
    @Override
    public String deleteMenu(int custid, int menuid) throws AddToCartNotFoundException, MenuNotFoundException {     
    	MenuDTO menu = menuService.getMenuById(menuid); // Getting product by ID
        Cart cart = cartRepository.findByCustomerId(custid); // Finding cart by customer ID

        if (cart == null) { // If cart not found
            throw new AddToCartNotFoundException("Invalid customer Id"); // Throwing exception
        }
        if (menu == null) { // If product not found
            throw new MenuNotFoundException("Invalid Menu ID"); // Throwing exception
        }

        for (Integer menu1 : cart.getMenuId()) { // Iterating through products in cart
            if (menu1 == menuid) { // If product ID matches
                cart.setTotalItemsQuantity(cart.getTotalItemsQuantity() - 1); // Updating total quantity
                cart.setTotalItemPrice(cart.getTotalItemPrice() - menu.getMenuPrice()); // Updating total price
                cart.getMenuId().remove(menu1); // Removing product from cart
                break;
            }
        }

        if (cart.getTotalItemsQuantity() == 0) { // If total quantity becomes zero
            cartRepository.delete(cart); // Deleting cart
        } else {
            cartRepository.save(cart); // Saving cart to database
        }

        return "deleted Successfully"; // Returning success message
    }

    // Method to get cart by customer ID
    @Override
    public CartDTO getCartByCustomerId(int custid) {
        Cart cart = cartRepository.findByCustomerId(custid); // Finding cart by customer ID
        CartDTO cartDTO = new CartDTO(); // Creating new CartDTO object
        // Setting cart details to DTO
        cartDTO.setCartId(cart.getCartId());
        cartDTO.setCustomerId(cart.getCustomerId());
        cartDTO.setMenuId(cart.getMenuId());
        cartDTO.setTotalItemPrice(cart.getTotalItemPrice());
        cartDTO.setTotalItemsQuantity(cart.getTotalItemsQuantity());
        return cartDTO; // Returning cart DTO
    }

    // Method to delete cart by ID
    @Override
    public String deleteCart(int cartId) {
        cartRepository.deleteById(cartId); // Deleting cart by ID
        return "Cart deleted."; // Returning success message
    }

}
