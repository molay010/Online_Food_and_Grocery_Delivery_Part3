package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.CartDTO; // Importing CartDTO for data transfer between controller and service
import com.cg.exception.AddToCartNotFoundException; // Importing AddToCartNotFoundException for handling exceptions
import com.cg.exception.CustomerNotFoundException; // Importing CustomerNotFoundException for handling exceptions
import com.cg.exception.MenuNotFoundException;
import com.cg.serviceImpl.CartServiceImpl; // Importing CartServiceImpl for Cart related service operations

@RestController // Indicates that this class is a REST controller
@RequestMapping("/cart") // Mapping for all endpoints in this controller
//@CrossOrigin(origins = "http://localhost:3000/")	//Frontend Connection
public class CartController {

    @Autowired // Autowires CartServiceImpl for dependency injection
    CartServiceImpl cartServiceImpl;
    
    // Endpoint to add a product to the cart
    @PostMapping("/add")
    public CartDTO addToCart(@RequestBody CartDTO cartDTO) throws CustomerNotFoundException, MenuNotFoundException {
        return cartServiceImpl.addToCart(cartDTO);
    }


    // Endpoint to delete a product from the cart
    @DeleteMapping("/deleteProducts/{customerId}/{menuId}")
    public String deletemenuCart(@PathVariable(value = "customerId") int customerId,
            @PathVariable(value = "productId") int menuId) throws MenuNotFoundException, AddToCartNotFoundException {
        cartServiceImpl.deleteMenu(customerId, menuId); // Calls service method to delete product from cart
        return "deleted successfully"; // Returning success message
    }
    
    // Endpoint to get cart by customer ID
    @GetMapping("/getByCustomerId/{custId}")
    public CartDTO getCartByCustomerId(@PathVariable("custId") int customerId) {
        return cartServiceImpl.getCartByCustomerId(customerId); // Calls service method to get cart by customer ID
    }
    
    // Endpoint to delete cart by ID
    @DeleteMapping("/delete/{cartId}")
    public String deleteCart(@PathVariable("cartId") int cartId) {
        return cartServiceImpl.deleteCart(cartId); // Calls service method to delete cart by ID
    }
}
