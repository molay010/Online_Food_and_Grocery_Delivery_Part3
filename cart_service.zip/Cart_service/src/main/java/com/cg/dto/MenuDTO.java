package com.cg.dto;

import lombok.Data;

@Data
public class MenuDTO {
	
	private int menuId;
	
	private String menuName;
	
	private int restaurantId;
   
    private String menuDescription;
	
	private double menuPrice;
	
}
