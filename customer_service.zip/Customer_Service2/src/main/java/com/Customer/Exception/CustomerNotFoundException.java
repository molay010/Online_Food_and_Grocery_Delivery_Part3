package com.Customer.Exception;

public class CustomerNotFoundException extends Exception {

	public CustomerNotFoundException() {
		super();

	}

	public CustomerNotFoundException(String string) {
		super(string);
	}

}
