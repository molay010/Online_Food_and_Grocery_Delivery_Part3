package com.Customer.Service;

import java.util.List;

import com.Customer.Exception.CustomerNotFoundException;
import com.Customer.entity.Customer;

public interface CustomerService {

    public Customer registerCustomer(Customer customer);

    public String updateCustomer(int customerId, Customer customer);

    public String deleteCustomer(int customerId);

    public List<Customer> getByEmail(String customerEmail) throws CustomerNotFoundException;

    public Customer getCustomerById(int customerId) throws CustomerNotFoundException;

    public List<Customer> readAllCustomers();
    
    
}
