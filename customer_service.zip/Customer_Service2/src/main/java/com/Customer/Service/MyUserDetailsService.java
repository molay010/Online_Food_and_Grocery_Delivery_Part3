package com.Customer.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.Customer.Repositary.CustomerRepository;
import com.Customer.entity.Customer;
import com.Customer.entity.MyUserDetails;
@Service
public class MyUserDetailsService implements UserDetailsService {
	@Autowired
	private CustomerRepository customerRepo;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		System.out.println(username);
		Customer cust=customerRepo.findByUsername(username);
		System.out.println(cust);
		if(cust==null) {
			throw new UsernameNotFoundException("User not found");
		}
		return new MyUserDetails(cust);
	}

}
