package com.Customer.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class customerLogin {

    private String customerUsername;
	
    private String customerPassword;
}
