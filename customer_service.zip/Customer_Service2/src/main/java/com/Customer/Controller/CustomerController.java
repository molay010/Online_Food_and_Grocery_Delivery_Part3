package com.Customer.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Customer.DTO.customerLogin;
import com.Customer.Exception.CustomerNotFoundException;
import com.Customer.entity.Customer;
import com.Customer.serviceImpl.CustomerServiceImplementation;

@RestController
@RequestMapping("/customers") 
public class CustomerController {

    @Autowired
    private CustomerServiceImplementation customerServiceImpl;

    @PostMapping("/register")
    public Customer addCustomer(@RequestBody Customer customer) {
        return customerServiceImpl.registerCustomer(customer);
    }

    @PostMapping("/login")
    public String loginCustomer(@RequestBody customerLogin customer) {
        return customerServiceImpl.verify(customer);
    }

    @GetMapping("/all")
    public List<Customer> readAllCustomers() {
        return customerServiceImpl.readAllCustomers();
    }

    @PutMapping("/update/{customerId}")
    public String updateCustomer(@PathVariable(value = "customerId") int customerId, @RequestBody Customer customer) {
        return customerServiceImpl.updateCustomer(customerId, customer);
    }

    @DeleteMapping("/delete/{customerId}")
    public String deleteCustomer(@PathVariable(value = "customerId") int customerId) {
        return customerServiceImpl.deleteCustomer(customerId);
    }

    @GetMapping("/byEmail/{customerEmail}")
    public List<Customer> getCustomerByEmail(@PathVariable(value = "customerEmail") String customerEmail) throws CustomerNotFoundException {
        return customerServiceImpl.getByEmail(customerEmail);
    }

    @GetMapping("/byId/{customerId}")
    public Customer getCustomerById(@PathVariable(value = "customerId") int customerId) throws CustomerNotFoundException {
        return customerServiceImpl.getCustomerById(customerId);
    }
}
