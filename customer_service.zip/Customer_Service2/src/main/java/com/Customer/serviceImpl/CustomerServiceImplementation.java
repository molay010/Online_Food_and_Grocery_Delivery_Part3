package com.Customer.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.Customer.DTO.customerLogin;
import com.Customer.Exception.CustomerNotFoundException;
import com.Customer.Repositary.CustomerRepository;
import com.Customer.Service.CustomerService;
import com.Customer.entity.Customer;
import com.Customer.utils.jwtService;

@Service
public class CustomerServiceImplementation implements CustomerService {
    
    @Autowired
    private AuthenticationManager auth;

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Customer registerCustomer(Customer customer) {
        BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder(12);
        customer.setCustomerPassword(bcrypt.encode(customer.getCustomerPassword()));
        return customerRepository.save(customer);
    }

    @Override
    public List<Customer> readAllCustomers() {
        return customerRepository.findAll();
    }

    @Override
    public String updateCustomer(int id, Customer customer) {
        try {
            Customer existingCustomer = customerRepository.findById(id).orElseThrow(() -> new CustomerNotFoundException());
            if (customer.getCustomerUsername() != null) existingCustomer.setCustomerUsername(customer.getCustomerUsername());
            if (customer.getPhoneNumber() != 0) existingCustomer.setPhoneNumber(customer.getPhoneNumber());
            if (customer.getCustomerAddress() != null) existingCustomer.setCustomerAddress(customer.getCustomerAddress());
            if (customer.getCustomerEmail() != null) existingCustomer.setCustomerEmail(customer.getCustomerEmail());
            customerRepository.save(existingCustomer);
        } catch (CustomerNotFoundException e) {
            return "Invalid customer.Customer data not updated";
        }
        return "Customer Updated Successfully";
    }

    @Override
    public String deleteCustomer(int customerId) {
        try {
            customerRepository.findById(customerId).orElseThrow(() -> new CustomerNotFoundException());
            customerRepository.deleteById(customerId);
        } catch (CustomerNotFoundException e) {
            return "Invalid customer id";
        }
        return "Customer deleted successfully.";
    }

    @Override
    public List<Customer> getByEmail(String email) throws CustomerNotFoundException {
        List<Customer> customers = customerRepository.findByEmail(email);
        if (customers.isEmpty()) {
            throw new CustomerNotFoundException("Invalid email");
        }
        return customers;
    }

    @Override
    public Customer getCustomerById(int customerId) throws CustomerNotFoundException {
        return customerRepository.findById(customerId).orElseThrow(() -> new CustomerNotFoundException("Invalid customer ID"));
    }

    public String verify(customerLogin customer) {
        Authentication authenticate = auth.authenticate(new UsernamePasswordAuthenticationToken(customer.getCustomerUsername(), customer.getCustomerPassword()));
        if (authenticate.isAuthenticated()) {
            return jwtService.generateToken(customer.getCustomerUsername());
        }
        return "fails";
    }
}
